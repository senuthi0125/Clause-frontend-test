import DashboardPage from "./pages/dashboard-page";

function App() {
  return <DashboardPage />;
}

export default App;